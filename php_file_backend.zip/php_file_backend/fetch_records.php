<?php

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$conn = mysqli_connect('localhost','root','','csab');


$data = json_decode(file_get_contents("php://input"));

$id = $data->id;

$sql = "SELECT Distinct `table 2`.Institute_Name  from `table 1` 
        JOIN `table 2`  ON `table 1`.c_id = `table 2`.Institute_Type_Id
        WHERE `table 2`.Institute_Type_Id ='".$id."'" ;

$query = mysqli_query($conn,$sql);

$output = []; //OR  $output = array(); 
 
   while($row=mysqli_fetch_assoc($query))
   {
    $output[] = array(  
            "id" => $row['Institute_Name'],  
                        "City_Name" => $row['Institute_Name'], 
                    ); 
   }

   echo json_encode($output,JSON_PRETTY_PRINT);
   ?>
<?php 

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$conn = mysqli_connect("localhost","root","","csab");

$data = json_decode(file_get_contents("php://input"));
//$ctyID = $data->cityID;
$InsName=$data->insName;
$Branch=$data->selectedbranch;
$Category=$data->selectedcategory;
$quota=$data->selectedquota;
$Year=$data->selectedyear;
$Round=$data->selectedround;
$Gender=$data->selectedgender;


$sql = "SELECT * from `table 2` WHERE `table 2`.Institute_Name = '".$InsName."' AND `table 2`.Academic_Program = '".$Branch."' AND `table 2`.Seat_Type = '".$Category."' AND `table 2`.Year = '".$Year."' AND `table 2`.Round = '".$Round."' AND `table 2`.Gender = '".$Gender."' " ;

$query = mysqli_query($conn,$sql);

$output = array();

while($row=mysqli_fetch_assoc($query))
 {
    //  $output[] = $row;
    $output[] = array(  
        "Institute_Name" => $row['Institute_Name'], 
        "Branch" => $row['Academic_Program'],
        "Opening_Rank"=>$row['Opening_Rank'],
        "Closing_Rank"=>$row['Closing_Rank'],
        "Quota" => $row['Quota'],
        "Category" => $row['Seat_Type'],   
        "Year" => $row['Year'], 
        "Gender"=>$row['Gender'],
        "Round"=>$row['Round']
    ); 
 
 }
 echo json_encode($output);
?>
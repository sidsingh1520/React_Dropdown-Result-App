<?php 

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$conn = mysqli_connect("localhost","root","","csab");

$data = json_decode(file_get_contents("php://input"));
$InsName=$data->insName;
$Branch=$data->selectedbranch;
$Year=$data->Year;



$sql = "SELECT DISTINCT `table 2`.Seat_Type from `table 2` WHERE `table 2`.Institute_Name = '".$InsName."' AND `table 2`.Academic_Program = '".$Branch."' AND `table 2`.Year = '".$Year."'  ";

$query = mysqli_query($conn,$sql);

$output = array();

while($row=mysqli_fetch_assoc($query))
 {
    //  $output[] = $row;
    $output[] = array(  
                "Seat_Type" => $row['Seat_Type'], 
    ); 
 
 }
 echo json_encode($output);
?>